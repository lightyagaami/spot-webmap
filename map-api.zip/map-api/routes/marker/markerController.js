const express = require('express');
const markerRouter = express.Router();
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const ObjectID = require('mongoose').Types.ObjectId;

const {MarkerModel} = require('../../models/markerModel');

const newMarker = mongoose.model('markers', MarkerModel);

// markerRouter.get('/', async(req, res) => {
//     const markerList =  MarkerModel.find();
//         if (!markerList) {
//             res.status(500).json('No data')
//         }
//         res.send(markerList);
    
// });
markerRouter.get('/', (req, res) => {
    newMarker.find((err, docs) => {
        if (!err) res.send(docs);
        else console.log("Error no data found: " + err);
    })
});



markerRouter.post('/',(req, res)=>{
    const newRecord = new newMarker({
        description: req.body.description,
        latitude : req.body.latitude,
        longitude: req.body.longitude
    });
    
    newRecord.save((err, docs) => {
        if (!err) res.send(docs);
        else console.log('Error creating new data: ' + err);
    })
});

markerRouter.put('/:id', (req, res)=>{
    if (!ObjectID.isValid(req.params.id))
        return res.status(400).send("ID unknow : "+ req.params.id)
    const updateRecord = {
        description: req.body.description,
        latitude : req.body.latitude,
        longitude: req.body.longitude
    };
    newMarker.findByIdAndUpdate(
        req.params.id,
        { $set: updateRecord},
        { new: true},
        (err, docs) => {
            if (!err) res.send(docs);
            else console.log("Update error : "+ err);
        }

    )
})
markerRouter.delete('/:id', (req, res)=>{
    if (!ObjectID.isValid(req.params.id))
        return res.status(400).send("ID unknow : "+ req.params.id)

    newMarker.findByIdAndRemove(
        req.params.id,
        (err, docs) => {
            if (!err) res.send(docs);
            else console.log("Delete error : "+ err);
        }
    );
})
module.exports = markerRouter;