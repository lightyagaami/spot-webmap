const express = require('express');
const userRouter = express.Router();
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const ObjectID = require('mongoose').Types.ObjectId;

const {UserModel} = require('../../models/userModel');

const newUser = mongoose.model('users', UserModel);

userRouter.get('/', (req, res) => {
    newUser.find((err, docs) => {
        if (!err) res.send(docs);
        else console.log("Error no data found: " + err);
    })
});

userRouter.post('/',(req, res)=>{
    const newRecord = new newUser({
        nom: req.body.nom,
        nomUtilisateur : req.body.nomUtilisateur,
        password: req.body.password,
        role: req.body.role
    });
    
    newRecord.save((err, docs) => {
        if (!err) res.send(docs);
        else console.log('Error creating new data: ' + err);
    })
})
userRouter.put('/:id', (req, res)=>{
    if (!ObjectID.isValid(req.params.id))
        return res.status(400).send("ID unknow : "+ req.params.id)
    const updateRecord = {
        nom: req.body.nom,
        nomUtilisateur : req.body.nomUtilisateur,
        password: req.body.password,
        role: req.body.role
    };
    newUser.findByIdAndUpdate(
        req.params.id,
        { $set: updateRecord},
        { new: true},
        (err, docs) => {
            if (!err) res.send(docs);
            else console.log("Update error : "+ err);
        }

    )
});
userRouter.delete('/:id', (req, res)=>{
    if (!ObjectID.isValid(req.params.id))
        return res.status(400).send("ID unknow : "+ req.params.id)

    newUser.findByIdAndRemove(
        req.params.id,
        (err, docs) => {
            if (!err) res.send(docs);
            else console.log("Delete error : "+ err);
        }
    );
}) 

module.exports = userRouter;