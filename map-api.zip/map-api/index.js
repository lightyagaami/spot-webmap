const express = require('express');
const app = express();
require('./models/dbConfig');
const markerRouter = require('./routes/marker/markerController');
const userRouter = require('./routes/user/userController');
const bodyParser = require('body-parser');
const cors =  require('cors');

app.use(bodyParser.json());
app.use(cors());
app.use('/markers', markerRouter);
app.use('/users', userRouter);






app.listen(9000, ()=> console.log('Server started: 9000'));