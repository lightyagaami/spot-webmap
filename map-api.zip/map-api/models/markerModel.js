const mongoose = require('mongoose');

const MarkerModel = mongoose.Schema(
    {
        date_time: {
            type: Date,
            default: Date.now
        },
        description: {
            type: String,
            required: true,
            min: 1,
            max: 255
        },
        latitude: {
            type: Number,
            required: true
        },
        longitude: {
            type: Number,
            required: true
        },


    },
    
);

module.exports = mongoose.model('markers', MarkerModel);