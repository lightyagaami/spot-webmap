const mongoose = require('mongoose');

const UserModel = mongoose.Schema(
    {
        nom: {
            type: String,
            required: true,
            min: 2,
            max: 100
        },
        nomUtilisateur: {
            type: String,
            required: true,
            min: 3,
            max: 255
        },
        password: {
            type: String,
            required: true,
            min: 0,
            max: 255
        },
        role: {
            type: String,
            required: true,
            min: 2,
            max: 100
        },
        
    },
    
);

module.exports = mongoose.model('users', UserModel);