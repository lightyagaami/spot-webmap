const mongoose = require('mongoose');

mongoose.set("strictQuery",true);
mongoose.connect(
    "mongodb://127.0.0.1:27017/",
    { useNewUrlParser: true, useUnifiedTopology: true,dbName:'map-api'},
    (err) => {
        if (!err) console.log("Mongo Database connected");
        else console.log("Error connection on Database: " + err);
    }
)